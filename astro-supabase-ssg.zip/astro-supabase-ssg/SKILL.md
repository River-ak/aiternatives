---
name: astro-supabase-ssg
description: Integrate Supabase PostgreSQL with Astro static site generation (SSG). Use when building Astro sites that fetch data from Supabase at build time, seed databases, configure GitHub Actions env vars, and deploy to Cloudflare Pages.
agent_created: true
---

# Astro + Supabase SSG Integration

## Overview

Connect an Astro SSG project to Supabase so pages fetch data at build time and deploy statically to Cloudflare Pages. Includes database schema execution, seed data insertion, client setup, CI/CD env vars, and a dynamic page refactor example.

## When to Use

- Astro project needs content from Supabase PostgreSQL
- Build-time data fetching for static pages (SSG, not SSR)
- Setting up GitHub Actions with Supabase secrets for Cloudflare Pages deployment
- Seeding Supabase with deterministic UUIDs and JSONB arrays

## Workflow

### 1. Verify Supabase Credentials

Ensure `SUPABASE_URL` and `SUPABASE_SERVICE_KEY` are available. Store them in:
- Local `.env` (never commit)
- GitHub Secrets for CI/CD

### 2. Execute Schema

Use Supabase SQL Editor for initial schema creation:
- Path: `https://supabase.com/dashboard/project/{ref}/sql/new`
- Or use `supabase` skill / REST API if `exec_sql` RPC exists

Typical schema includes:
- `tools` table with UUID PK, JSONB `features`, `metadata`
- `alternatives` relationship table with quality_score and FKs
- `deals` table with pricing and expiration
- Indexes, updated_at triggers, RLS read policies

### 3. Seed Data

Use `scripts/seed_supabase.py` pattern:
- Generate deterministic UUIDs via `uuid.uuid5(uuid.NAMESPACE_URL, slug_url)`
- Normalize all rows to identical keys before batch insert
- Insert via Supabase REST POST `/rest/v1/{table}`
- Truncate existing data with `id=not.is.null` filter for tables lacking `is_active`

### 4. Create Astro Client

Create `src/lib/supabase.ts`:

```ts
import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.SUPABASE_URL;
const key = import.meta.env.SUPABASE_SERVICE_KEY;
if (!url || !key) throw new Error('Missing Supabase env vars');

export const supabase = createClient(url, key, {
  auth: { autoRefreshToken: false, persistSession: false },
});
```

### 5. Build-Time Fetch

In `.astro` pages, call Supabase in frontmatter:

```astro
---
import { getAlternativesForSource } from '../../lib/supabase';
const alternatives = await getAlternativesForSource('chatgpt');
---
```

Map snake_case DB columns to component's camelCase interface.

### 6. CI/CD Setup

Update `.github/workflows/deploy.yml` Build step:

```yaml
- name: Build
  run: npm run build
  env:
    SUPABASE_URL: ${{ secrets.SUPABASE_URL }}
    SUPABASE_SERVICE_KEY: ${{ secrets.SUPABASE_SERVICE_KEY }}
```

### 7. Common Pitfalls

- **Batch insert key mismatch**: every object in array must have identical keys; fill missing with `null`
- **JSON escaping in SQL Editor**: paste plain JSON like `'["a","b"]'`, not escaped `'[\"a\",\"b\"]'`
- **DELETE without WHERE**: Supabase REST requires a filter; use `id=not.is.null`
- **CHECK constraints**: `commission_type` must match allowed enum values
- **Service key exposure**: never commit `.env`; use GitHub Secrets only

## Resources

- `scripts/seed_supabase.py`: deterministic UUID seeding + batch REST inserts
